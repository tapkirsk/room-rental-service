<script>
alert("<?php session_start();echo $_SESSION['oid']; ?>");
</script>
